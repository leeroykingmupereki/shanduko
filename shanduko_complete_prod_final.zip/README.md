Shanduko — Complete Production Prototype (MinIO + Worker)

What's included:
 - Full React client (Vite + Tailwind) with auth and project dashboard
 - Express server with Prisma (SQLite), JWT auth, MinIO S3 uploads, Bull queue and worker
 - Dockerfiles and docker-compose (Redis, MinIO, server, worker, client)
 - Sample logos and assets

Quick local run (recommended via docker-compose):
 1) docker-compose up --build
 2) Open MinIO console at http://localhost:9001 (user/minioadmin, pass/minioadmin) and create bucket 'shanduko'
 3) Optionally run `docker exec -it <server_container> npx prisma generate` to ensure Prisma client
 4) Open client at http://localhost:5173

Security notes:
 - Change JWT_SECRET and MinIO credentials before public deployment.
 - Use Postgres for production instead of SQLite and secure storage for MinIO.
